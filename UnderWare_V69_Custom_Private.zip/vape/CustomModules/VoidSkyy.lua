game.Lighting.Sky.SkyboxBk = "http://www.roblox.com/asset/?id=9851144466"
game.Lighting.Sky.SkyboxDn = "http://www.roblox.com/asset/?id=9851144249"
game.Lighting.Sky.SkyboxFt = "http://www.roblox.com/asset/?id=9851144099"
game.Lighting.Sky.SkyboxLf = "http://www.roblox.com/asset/?id=9851143942"
game.Lighting.Sky.SkyboxRt = "http://www.roblox.com/asset/?id=9851143761"
game.Lighting.Sky.SkyboxUp = "http://www.roblox.com/asset/?id=9851143257"
game.Lighting.FogColor = Color3.new(236, 88, 241)
game.Lighting.FogEnd = "200"
game.Lighting.FogStart = "0"
game.Lighting.Ambient = Color3.new(0.5, 0, 1)